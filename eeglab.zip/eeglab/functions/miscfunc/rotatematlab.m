function rotatematlab(varargin)
% This function calls the Matlab rotate function
% This prevents the issue with the function in the private folder of Dipfit

rotate(varargin{:});
